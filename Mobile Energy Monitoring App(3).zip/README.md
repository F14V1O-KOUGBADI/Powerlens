
  # Mobile Energy Monitoring App

  This is a code bundle for Mobile Energy Monitoring App. The original project is available at https://www.figma.com/design/Wf6Lr7BD8hlsPSpDSE4IsS/Mobile-Energy-Monitoring-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  