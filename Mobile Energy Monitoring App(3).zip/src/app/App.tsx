import { useState } from 'react';
import { Home, BarChart3, Zap, GitBranch, Bell, FileText, Settings, Building2 } from 'lucide-react';
import { BuildingProvider, useBuilding } from './contexts/building-context';
import { ControlCenter } from './components/control-center';
import { Dashboard } from './components/dashboard';
import { Equipment } from './components/equipment';
import { ActionsReactions } from './components/actions-reactions';
import { Alerts } from './components/alerts';
import { Reports } from './components/reports';
import { SettingsScreen } from './components/settings-screen';

type Screen = 'control' | 'dashboard' | 'equipment' | 'actions' | 'alerts' | 'reports' | 'settings';

function AppContent() {
  const [activeScreen, setActiveScreen] = useState<Screen>('control');
  const buildingContext = useBuilding();
  const { buildings, activeBuilding, setActiveBuilding } = buildingContext;

  const navItems = [
    { id: 'control' as Screen, label: 'Contrôle', icon: Home },
    { id: 'dashboard' as Screen, label: 'Dashboard', icon: BarChart3 },
    { id: 'equipment' as Screen, label: 'Équipements', icon: Zap },
    { id: 'actions' as Screen, label: 'Actions', icon: GitBranch },
    { id: 'alerts' as Screen, label: 'Alertes', icon: Bell },
    { id: 'reports' as Screen, label: 'Rapports', icon: FileText },
    { id: 'settings' as Screen, label: 'Paramètres', icon: Settings },
  ];

  // Ensure we have buildings before rendering
  if (buildings.length === 0) {
    return (
      <div className="h-screen flex items-center justify-center bg-slate-900 text-white">
        <div className="text-center">
          <Building2 className="w-12 h-12 mx-auto mb-4 text-slate-600" />
          <p className="text-slate-400">Chargement...</p>
        </div>
      </div>
    );
  }

  const renderScreen = () => {
    switch (activeScreen) {
      case 'control':
        return <ControlCenter />;
      case 'dashboard':
        return <Dashboard />;
      case 'equipment':
        return <Equipment />;
      case 'actions':
        return <ActionsReactions />;
      case 'alerts':
        return <Alerts />;
      case 'reports':
        return <Reports />;
      case 'settings':
        return <SettingsScreen />;
      default:
        return <ControlCenter />;
    }
  };

  return (
    <div className="h-screen flex flex-col bg-slate-900 text-white max-w-md mx-auto">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 px-4 py-3 flex-shrink-0">
        <h1 className="text-lg font-semibold">SMART ENERGY</h1>
        <div className="flex items-center gap-2 text-xs text-slate-400 mt-1">
          <Building2 className="w-3 h-3" />
          <span>{activeBuilding?.name || 'Aucun bâtiment'}</span>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        {renderScreen()}
      </main>

      {/* Bottom Navigation */}
      <nav className="bg-slate-800 border-t border-slate-700 flex-shrink-0">
        <div className="grid grid-cols-4 gap-1 p-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeScreen === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveScreen(item.id)}
                className={`flex flex-col items-center gap-1 p-2 rounded transition-colors ${
                  isActive
                    ? 'bg-blue-600 text-white'
                    : 'text-slate-400 hover:bg-slate-700 hover:text-white'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs">{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

export default function App() {
  return (
    <BuildingProvider>
      <AppContent />
    </BuildingProvider>
  );
}