import { TrendingUp, TrendingDown, Activity, Building2 } from 'lucide-react';
import { useBuilding } from '@/app/contexts/building-context';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const consumptionData = [
  { time: '00h', value: 120 },
  { time: '04h', value: 85 },
  { time: '08h', value: 240 },
  { time: '12h', value: 310 },
  { time: '16h', value: 285 },
  { time: '20h', value: 195 },
  { time: '24h', value: 130 },
];

export function Dashboard() {
  const { activeBuilding } = useBuilding();

  if (!activeBuilding) {
    return (
      <div className="p-4 flex items-center justify-center h-full">
        <div className="text-center text-slate-400">
          <Building2 className="w-12 h-12 mx-auto mb-2" />
          <p>Aucun bâtiment sélectionné</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-6">
      {/* Building Info */}
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <h2 className="text-sm font-medium text-slate-400 mb-1">TABLEAU DE BORD</h2>
        <p className="text-xl font-bold">{activeBuilding.name}</p>
      </div>

      {/* Real-time Metrics */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-green-400" />
            <p className="text-xs text-slate-400">Consommation Actuelle</p>
          </div>
          <p className="text-2xl font-mono font-bold text-green-400">{activeBuilding.currentPower} kW</p>
          <p className="text-xs text-green-400 flex items-center gap-1 mt-1">
            <TrendingDown className="w-3 h-3" />
            -12% vs hier
          </p>
        </div>

        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <div className="flex items-center gap-2 mb-2">
            <Activity className="w-4 h-4 text-blue-400" />
            <p className="text-xs text-slate-400">Conso. Journée</p>
          </div>
          <p className="text-2xl font-mono font-bold text-blue-400">4.8 MWh</p>
          <p className="text-xs text-red-400 flex items-center gap-1 mt-1">
            <TrendingUp className="w-3 h-3" />
            +5% vs hier
          </p>
        </div>
      </div>

      {/* Consumption Chart */}
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <h2 className="text-sm font-medium text-slate-400 mb-1">CONSOMMATION SBEE (30 JOURS)</h2>
        <p className="text-xs text-slate-500 mb-4">Société Béninoise d'Énergie Électrique</p>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={consumptionData}>
            <defs>
              <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
            <XAxis dataKey="time" stroke="#94a3b8" style={{ fontSize: '12px' }} />
            <YAxis stroke="#94a3b8" style={{ fontSize: '12px' }} />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1e293b', 
                border: '1px solid #475569',
                borderRadius: '8px',
                color: '#fff'
              }} 
            />
            <Area 
              type="monotone" 
              dataKey="value" 
              stroke="#3b82f6" 
              strokeWidth={2}
              fillOpacity={1} 
              fill="url(#colorValue)" 
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Room Consumption */}
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <h2 className="text-sm font-medium text-slate-400 mb-4">CONSOMMATION PAR SALLE</h2>
        <div className="space-y-3">
          {activeBuilding.rooms.map((room) => {
            const percent = (room.power / activeBuilding.maxPower) * 100;
            return (
              <div key={room.id}>
                <div className="flex justify-between items-center mb-1">
                  <span className="text-sm">{room.name}</span>
                  <span className="text-sm font-mono text-green-400">{room.power} kW</span>
                </div>
                <div className="w-full bg-slate-700 rounded-full h-2">
                  <div 
                    className="bg-blue-500 h-2 rounded-full transition-all"
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Energy Sources */}
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <h2 className="text-sm font-medium text-slate-400 mb-4">SOURCE D'ÉNERGIE</h2>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm">SBEE (Réseau électrique)</span>
            <span className="text-sm font-mono text-green-400">{activeBuilding.currentPower} kW (100%)</span>
          </div>
        </div>
      </div>
    </div>
  );
}