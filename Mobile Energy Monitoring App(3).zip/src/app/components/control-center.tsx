import { useState } from 'react';
import { Power, AlertTriangle, Zap, Building2 } from 'lucide-react';
import { useBuilding } from '@/app/contexts/building-context';
import type { BuildingStatus } from '@/app/contexts/building-context';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';

type ActionType = 'cutoff' | 'restore';

export function ControlCenter() {
  const { activeBuilding, updateBuilding, addAlert } = useBuilding();
  const [showConfirmDialog, setShowConfirmDialog] = useState(false);
  const [pendingAction, setPendingAction] = useState<ActionType | null>(null);

  if (!activeBuilding) {
    return (
      <div className="p-4 flex items-center justify-center h-full">
        <div className="text-center text-slate-400">
          <Building2 className="w-12 h-12 mx-auto mb-2" />
          <p>Aucun bâtiment sélectionné</p>
        </div>
      </div>
    );
  }

  const handleAction = (action: ActionType) => {
    setPendingAction(action);
    setShowConfirmDialog(true);
  };

  const confirmAction = () => {
    if (!activeBuilding) return;
    
    let newStatus: BuildingStatus = activeBuilding.status;
    
    if (pendingAction === 'cutoff') {
      newStatus = 'cutoff';
    } else if (pendingAction === 'restore') {
      newStatus = 'powered';
    }
    
    updateBuilding(activeBuilding.id, { status: newStatus });
    
    addAlert({
      type: newStatus === 'cutoff' ? 'coupure' : 'action',
      message: `Bâtiment ${newStatus === 'cutoff' ? 'coupé' : 'rétabli'}`,
      origin: 'manuel'
    });
    
    setShowConfirmDialog(false);
    setPendingAction(null);
  };

  const getStatusConfig = () => {
    switch (activeBuilding.status) {
      case 'powered':
        return { color: 'bg-green-500', text: 'Alimenté', icon: Power };
      case 'cutoff':
        return { color: 'bg-red-500', text: 'Coupé', icon: Power };
    }
  };

  const statusConfig = getStatusConfig();
  const StatusIcon = statusConfig.icon;

  return (
    <div className="p-4 space-y-6">
      {/* Building Status */}
      <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
        <h2 className="text-sm font-medium text-slate-400 mb-4">ÉTAT DU BÂTIMENT</h2>
        <div className="flex items-center gap-4">
          <div className={`${statusConfig.color} p-3 rounded-full`}>
            <StatusIcon className="w-6 h-6 text-white" />
          </div>
          <div>
            <p className="text-2xl font-bold">{statusConfig.text}</p>
            <p className="text-sm text-slate-400">{activeBuilding.name}</p>
          </div>
        </div>
      </div>

      {/* Energy Flow Diagram */}
      <div className="bg-slate-800 rounded-lg p-6 border border-slate-700">
        <h2 className="text-sm font-medium text-slate-400 mb-4">CONSOMMATION ÉLECTRIQUE</h2>
        <p className="text-xs text-slate-500 mb-4">Intervalle : 30 derniers jours</p>
        <div className="space-y-4">
          {/* SBEE - Société Béninoise d'Énergie Électrique */}
          <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded">
            <div className="flex items-center gap-3">
              <Zap className="w-5 h-5 text-blue-400" />
              <span>SBEE (Réseau)</span>
            </div>
            <span className="font-mono text-green-400">{activeBuilding.currentPower} kW</span>
          </div>
        </div>
      </div>

      {/* Power Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <p className="text-xs text-slate-400 mb-1">Consommation Totale</p>
          <p className="text-2xl font-mono font-bold text-green-400">{activeBuilding.currentPower} kW</p>
        </div>
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <p className="text-xs text-slate-400 mb-1">Seuil Maximum</p>
          <p className="text-2xl font-mono font-bold text-slate-300">{activeBuilding.maxPower} kW</p>
        </div>
      </div>

      {/* Critical Actions */}
      <div className="space-y-3">
        <h2 className="text-sm font-medium text-slate-400">ACTIONS CRITIQUES</h2>
        
        {activeBuilding.status !== 'cutoff' && (
          <button
            onClick={() => handleAction('cutoff')}
            className="w-full bg-red-600 hover:bg-red-700 text-white p-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
          >
            <Power className="w-5 h-5" />
            <span className="font-medium">Couper l'Alimentation</span>
          </button>
        )}

        {activeBuilding.status !== 'powered' && (
          <button
            onClick={() => handleAction('restore')}
            className="w-full bg-green-600 hover:bg-green-700 text-white p-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
          >
            <Power className="w-5 h-5" />
            <span className="font-medium">Rétablir l'Alimentation</span>
          </button>
        )}
      </div>

      {/* Confirmation Dialog */}
      <Dialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <DialogContent className="bg-slate-800 text-white border-slate-700">
          <DialogHeader>
            <DialogTitle>Confirmation Requise</DialogTitle>
            <DialogDescription className="text-slate-400">
              {pendingAction === 'cutoff' && 'Êtes-vous sûr de vouloir couper l\'alimentation du bâtiment ? Cette action affectera toutes les salles.'}
              {pendingAction === 'restore' && 'Êtes-vous sûr de vouloir rétablir l\'alimentation normale du bâtiment ?'}
            </DialogDescription>
          </DialogHeader>
          <div className="bg-orange-900/30 border border-orange-700 rounded p-3 my-4">
            <p className="text-sm text-orange-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Niveau de risque: {pendingAction === 'cutoff' ? 'ÉLEVÉ' : 'FAIBLE'}
            </p>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowConfirmDialog(false)}>
              Annuler
            </Button>
            <Button onClick={confirmAction} className="bg-blue-600 hover:bg-blue-700">
              Confirmer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}