import { AlertTriangle, ZapOff, Zap, Clock, User, Cog, Building2 } from 'lucide-react';
import { useBuilding } from '@/app/contexts/building-context';
import { Badge } from './ui/badge';

export function Alerts() {
  const { activeBuilding } = useBuilding();

  if (!activeBuilding) {
    return (
      <div className="p-4 flex items-center justify-center h-full">
        <div className="text-center text-slate-400">
          <Building2 className="w-12 h-12 mx-auto mb-2" />
          <p>Aucun bâtiment sélectionné</p>
        </div>
      </div>
    );
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'surcharge':
        return AlertTriangle;
      case 'coupure':
        return ZapOff;
      case 'limitation':
        return Zap;
      default:
        return Clock;
    }
  };

  const getAlertColor = (type: string) => {
    switch (type) {
      case 'surcharge':
        return 'bg-red-500';
      case 'coupure':
        return 'bg-orange-500';
      case 'limitation':
        return 'bg-yellow-500';
      default:
        return 'bg-blue-500';
    }
  };

  const formatTimestamp = (timestamp: string) => {
    const date = new Date(timestamp);
    return date.toLocaleString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="p-4 space-y-4">
      {/* Header */}
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <h2 className="text-sm font-medium text-slate-400 mb-1">ALERTES & ÉVÉNEMENTS</h2>
        <p className="text-2xl font-bold">{activeBuilding.alerts.length} Événements</p>
        <p className="text-xs text-slate-400 mt-1">{activeBuilding.name}</p>
      </div>

      {/* Alerts List */}
      <div className="space-y-3">
        {activeBuilding.alerts.length === 0 ? (
          <div className="bg-slate-800 rounded-lg p-8 border border-slate-700 text-center text-slate-400">
            <Clock className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Aucun événement enregistré</p>
          </div>
        ) : (
          activeBuilding.alerts.map((alert) => {
            const Icon = getAlertIcon(alert.type);
            const color = getAlertColor(alert.type);

            return (
              <div
                key={alert.id}
                className="bg-slate-800 rounded-lg p-4 border border-slate-700"
              >
                <div className="flex items-start gap-3">
                  <div className={`${color} p-2 rounded flex-shrink-0`}>
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <h3 className="font-medium">{alert.message}</h3>
                      <Badge 
                        variant={alert.origin === 'manuel' ? 'default' : 'secondary'}
                        className="flex-shrink-0"
                      >
                        {alert.origin === 'manuel' ? <User className="w-3 h-3 mr-1" /> : <Cog className="w-3 h-3 mr-1" />}
                        {alert.origin === 'manuel' ? 'Manuel' : 'Automatique'}
                      </Badge>
                    </div>
                    {alert.room && (
                      <p className="text-sm text-slate-400">Salle: {alert.room}</p>
                    )}
                    <p className="text-xs text-slate-500 mt-2 flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatTimestamp(alert.timestamp)}
                    </p>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}