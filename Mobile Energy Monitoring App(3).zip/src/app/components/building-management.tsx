import { useState } from 'react';
import { Building2, Plus, Edit2, Trash2, CheckCircle, AlertTriangle, Power } from 'lucide-react';
import { useBuilding, BuildingType, Building } from '@/app/contexts/building-context';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

export function BuildingManagement() {
  const { buildings, activeBuilding, addBuilding, updateBuilding, deleteBuilding, setActiveBuilding } = useBuilding();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [selectedBuilding, setSelectedBuilding] = useState<Building | null>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    type: 'campus' as BuildingType,
    maxPower: 350,
  });

  const resetForm = () => {
    setFormData({
      name: '',
      type: 'campus',
      maxPower: 350,
    });
  };

  const handleAdd = () => {
    if (!formData.name.trim()) return;
    
    addBuilding({
      name: formData.name,
      type: formData.type,
      status: 'powered',
      maxPower: formData.maxPower,
      currentPower: 0,
      rooms: [],
      equipment: [],
      actionReactions: [],
      alerts: [],
    });
    
    setShowAddDialog(false);
    resetForm();
  };

  const handleEdit = () => {
    if (!selectedBuilding || !formData.name.trim()) return;
    
    updateBuilding(selectedBuilding.id, {
      name: formData.name,
      type: formData.type,
      maxPower: formData.maxPower,
    });
    
    setShowEditDialog(false);
    setSelectedBuilding(null);
    resetForm();
  };

  const handleDelete = () => {
    if (selectedBuilding && buildings.length > 1) {
      deleteBuilding(selectedBuilding.id);
      setShowDeleteDialog(false);
      setSelectedBuilding(null);
    }
  };

  const openEditDialog = (building: Building) => {
    setSelectedBuilding(building);
    setFormData({
      name: building.name,
      type: building.type,
      maxPower: building.maxPower,
    });
    setShowEditDialog(true);
  };

  const openDeleteDialog = (building: Building) => {
    setSelectedBuilding(building);
    setShowDeleteDialog(true);
  };

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'powered':
        return { color: 'bg-green-500', text: 'Alimenté', icon: CheckCircle };
      case 'limited':
        return { color: 'bg-orange-500', text: 'Limité', icon: AlertTriangle };
      case 'cutoff':
        return { color: 'bg-red-500', text: 'Coupé', icon: Power };
      default:
        return { color: 'bg-gray-500', text: 'Inconnu', icon: AlertTriangle };
    }
  };

  const getBuildingTypeLabel = (type: BuildingType) => {
    const labels = {
      campus: 'Campus',
      école: 'École',
      bureau: 'Bureau',
      usine: 'Usine',
    };
    return labels[type];
  };

  return (
    <div className="p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold">Gestion des Bâtiments</h1>
          <p className="text-sm text-slate-400">{buildings.length} bâtiment(s) enregistré(s)</p>
        </div>
        <button
          onClick={() => setShowAddDialog(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>Ajouter</span>
        </button>
      </div>

      {/* Buildings List */}
      <div className="space-y-3">
        {buildings.map((building) => {
          const isActive = activeBuilding?.id === building.id;
          const statusConfig = getStatusConfig(building.status);
          const StatusIcon = statusConfig.icon;

          return (
            <div
              key={building.id}
              className={`bg-slate-800 rounded-lg border-2 transition-all ${
                isActive ? 'border-blue-500' : 'border-slate-700'
              }`}
            >
              {/* Building Header */}
              <div
                onClick={() => setActiveBuilding(building.id)}
                className="p-4 cursor-pointer hover:bg-slate-700/50 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <Building2 className="w-5 h-5 text-blue-400" />
                      <h3 className="font-semibold">{building.name}</h3>
                      {isActive && (
                        <span className="bg-blue-600 text-xs px-2 py-0.5 rounded-full">
                          Actif
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-slate-400">{getBuildingTypeLabel(building.type)}</p>
                  </div>

                  {/* Status Badge */}
                  <div className="flex items-center gap-2">
                    <div className={`${statusConfig.color} p-2 rounded`}>
                      <StatusIcon className="w-4 h-4 text-white" />
                    </div>
                  </div>
                </div>

                {/* Stats Grid */}
                <div className="grid grid-cols-3 gap-3 mt-4">
                  <div className="bg-slate-700/50 rounded p-2">
                    <p className="text-xs text-slate-400">Salles</p>
                    <p className="text-lg font-mono font-bold">{building.rooms.length}</p>
                  </div>
                  <div className="bg-slate-700/50 rounded p-2">
                    <p className="text-xs text-slate-400">Puissance</p>
                    <p className="text-lg font-mono font-bold text-green-400">
                      {building.currentPower} kW
                    </p>
                  </div>
                  <div className="bg-slate-700/50 rounded p-2">
                    <p className="text-xs text-slate-400">Max</p>
                    <p className="text-lg font-mono font-bold text-slate-300">
                      {building.maxPower} kW
                    </p>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="border-t border-slate-700 px-4 py-2 flex gap-2">
                <button
                  onClick={() => openEditDialog(building)}
                  className="flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-slate-700 hover:bg-slate-600 rounded transition-colors"
                >
                  <Edit2 className="w-4 h-4" />
                  <span className="text-sm">Modifier</span>
                </button>
                <button
                  onClick={() => openDeleteDialog(building)}
                  disabled={buildings.length === 1}
                  className="flex-1 flex items-center justify-center gap-2 py-2 px-3 bg-red-900/30 hover:bg-red-900/50 rounded transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Trash2 className="w-4 h-4" />
                  <span className="text-sm">Supprimer</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Building Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="bg-slate-800 text-white border-slate-700">
          <DialogHeader>
            <DialogTitle>Ajouter un Bâtiment</DialogTitle>
            <DialogDescription className="text-slate-400">
              Créez un nouveau bâtiment à superviser
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="name">Nom du bâtiment</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Ex: Bâtiment Sciences"
                className="bg-slate-700 border-slate-600 text-white mt-1"
              />
            </div>

            <div>
              <Label htmlFor="type">Type de bâtiment</Label>
              <Select
                value={formData.type}
                onValueChange={(value) => setFormData({ ...formData, type: value as BuildingType })}
              >
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600 text-white">
                  <SelectItem value="campus">Campus</SelectItem>
                  <SelectItem value="école">École</SelectItem>
                  <SelectItem value="bureau">Bureau</SelectItem>
                  <SelectItem value="usine">Usine</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="maxPower">Puissance maximale (kW)</Label>
              <Input
                id="maxPower"
                type="number"
                value={formData.maxPower}
                onChange={(e) => setFormData({ ...formData, maxPower: parseInt(e.target.value) || 0 })}
                className="bg-slate-700 border-slate-600 text-white mt-1"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowAddDialog(false); resetForm(); }}>
              Annuler
            </Button>
            <Button onClick={handleAdd} className="bg-blue-600 hover:bg-blue-700">
              Créer le bâtiment
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Building Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="bg-slate-800 text-white border-slate-700">
          <DialogHeader>
            <DialogTitle>Modifier le Bâtiment</DialogTitle>
            <DialogDescription className="text-slate-400">
              Modifiez les informations du bâtiment
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="edit-name">Nom du bâtiment</Label>
              <Input
                id="edit-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-slate-700 border-slate-600 text-white mt-1"
              />
            </div>

            <div>
              <Label htmlFor="edit-type">Type de bâtiment</Label>
              <Select
                value={formData.type}
                onValueChange={(value) => setFormData({ ...formData, type: value as BuildingType })}
              >
                <SelectTrigger className="bg-slate-700 border-slate-600 text-white mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600 text-white">
                  <SelectItem value="campus">Campus</SelectItem>
                  <SelectItem value="école">École</SelectItem>
                  <SelectItem value="bureau">Bureau</SelectItem>
                  <SelectItem value="usine">Usine</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="edit-maxPower">Puissance maximale (kW)</Label>
              <Input
                id="edit-maxPower"
                type="number"
                value={formData.maxPower}
                onChange={(e) => setFormData({ ...formData, maxPower: parseInt(e.target.value) || 0 })}
                className="bg-slate-700 border-slate-600 text-white mt-1"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowEditDialog(false); setSelectedBuilding(null); resetForm(); }}>
              Annuler
            </Button>
            <Button onClick={handleEdit} className="bg-blue-600 hover:bg-blue-700">
              Enregistrer
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="bg-slate-800 text-white border-slate-700">
          <DialogHeader>
            <DialogTitle>Supprimer le Bâtiment</DialogTitle>
            <DialogDescription className="text-slate-400">
              Êtes-vous sûr de vouloir supprimer "{selectedBuilding?.name}" ? Cette action est irréversible.
            </DialogDescription>
          </DialogHeader>

          <div className="bg-red-900/30 border border-red-700 rounded p-3 my-4">
            <p className="text-sm text-red-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Toutes les données associées (salles, équipements, règles) seront perdues.
            </p>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => { setShowDeleteDialog(false); setSelectedBuilding(null); }}>
              Annuler
            </Button>
            <Button onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Supprimer définitivement
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
