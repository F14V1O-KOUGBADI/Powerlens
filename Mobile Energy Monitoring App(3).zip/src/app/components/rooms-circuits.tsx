import { useState } from 'react';
import { Building2, Power, ChevronRight, Zap, AlertTriangle } from 'lucide-react';
import { useBuilding } from '@/app/contexts/building-context';
import type { BuildingStatus } from '@/app/contexts/building-context';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from './ui/dialog';
import { Button } from './ui/button';
import { Switch } from './ui/switch';

export function RoomsCircuits() {
  const { activeBuilding, updateRoomStatus, addAlert } = useBuilding();
  const [selectedRoomId, setSelectedRoomId] = useState<string | null>(null);

  if (!activeBuilding) {
    return (
      <div className="p-4 flex items-center justify-center h-full">
        <div className="text-center text-slate-400">
          <Building2 className="w-12 h-12 mx-auto mb-2" />
          <p>Aucun bâtiment sélectionné</p>
        </div>
      </div>
    );
  }

  const selectedRoom = activeBuilding.rooms.find(r => r.id === selectedRoomId);

  const getStatusColor = (status: BuildingStatus) => {
    switch (status) {
      case 'powered':
        return 'bg-green-500';
      case 'limited':
        return 'bg-orange-500';
      case 'cutoff':
        return 'bg-red-500';
    }
  };

  const getStatusText = (status: BuildingStatus) => {
    switch (status) {
      case 'powered':
        return 'Alimenté';
      case 'limited':
        return 'Limité';
      case 'cutoff':
        return 'Coupé';
    }
  };

  const toggleRoomPower = (roomId: string) => {
    const room = activeBuilding.rooms.find(r => r.id === roomId);
    if (!room) return;
    
    const newStatus: BuildingStatus = room.status === 'powered' ? 'cutoff' : 'powered';
    updateRoomStatus(roomId, newStatus);
  };

  const countEquipmentInRoom = (roomId: string) => {
    return activeBuilding.equipment.filter(e => e.roomId === roomId).length;
  };

  return (
    <div className="p-4 space-y-4">
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <h2 className="text-sm font-medium text-slate-400 mb-1">{activeBuilding.name.toUpperCase()}</h2>
        <p className="text-2xl font-bold">
          {activeBuilding.rooms.filter(r => r.status === 'powered').length} / {activeBuilding.rooms.length} Salles Actives
        </p>
      </div>

      {/* Rooms List */}
      <div className="space-y-3">
        {activeBuilding.rooms.length === 0 ? (
          <div className="bg-slate-800 rounded-lg p-8 border border-slate-700 text-center text-slate-400">
            <Building2 className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Aucune salle configurée pour ce bâtiment</p>
          </div>
        ) : (
          activeBuilding.rooms.map((room) => (
            <div
              key={room.id}
              className="bg-slate-800 rounded-lg p-4 border border-slate-700"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-start gap-3">
                  <div className={`${getStatusColor(room.status)} p-2 rounded`}>
                    <Building2 className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-medium">{room.name}</h3>
                      {room.isPriority && (
                        <span className="bg-orange-600 text-xs px-2 py-0.5 rounded">Prioritaire</span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400">{getStatusText(room.status)}</p>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedRoomId(room.id)}
                  className="text-blue-400 hover:text-blue-300 transition-colors"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              <div className="grid grid-cols-3 gap-3 mb-3">
                <div>
                  <p className="text-xs text-slate-400">Puissance</p>
                  <p className="font-mono font-medium text-green-400">{room.power} kW</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Circuits</p>
                  <p className="font-mono font-medium">4</p>
                </div>
                <div>
                  <p className="text-xs text-slate-400">Équipements</p>
                  <p className="font-mono font-medium">{countEquipmentInRoom(room.id)}</p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-slate-700">
                <span className="text-sm">Alimentation</span>
                <Switch
                  checked={room.status === 'powered'}
                  onCheckedChange={() => toggleRoomPower(room.id)}
                />
              </div>
            </div>
          ))
        )}
      </div>

      {/* Room Details Dialog */}
      <Dialog open={!!selectedRoom} onOpenChange={() => setSelectedRoomId(null)}>
        <DialogContent className="bg-slate-800 text-white border-slate-700">
          <DialogHeader>
            <DialogTitle>{selectedRoom?.name}</DialogTitle>
            <DialogDescription className="text-slate-400">
              Détails et contrôle des circuits
            </DialogDescription>
          </DialogHeader>

          {selectedRoom && (
            <div className="space-y-4">
              {/* Status Info */}
              <div className="bg-slate-700/50 rounded p-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-400">État actuel</span>
                  <span className={`text-sm font-medium ${
                    selectedRoom.status === 'powered' ? 'text-green-400' : 
                    selectedRoom.status === 'limited' ? 'text-orange-400' : 'text-red-400'
                  }`}>
                    {getStatusText(selectedRoom.status)}
                  </span>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-sm text-slate-400">Puissance</span>
                  <span className="text-sm font-mono text-green-400">{selectedRoom.power} kW</span>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-sm text-slate-400">Prioritaire</span>
                  <span className="text-sm">{selectedRoom.isPriority ? 'Oui' : 'Non'}</span>
                </div>
              </div>

              {/* Circuits */}
              <div>
                <h3 className="text-sm font-medium text-slate-400 mb-3">CIRCUITS</h3>
                <div className="space-y-2">
                  {['Éclairage', 'Climatisation', 'Prises', 'Équipements'].map((circuit, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 bg-slate-700/50 rounded">
                      <div className="flex items-center gap-2">
                        <Zap className="w-4 h-4 text-blue-400" />
                        <span className="text-sm">{circuit}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-sm font-mono text-green-400">
                          {Math.floor(selectedRoom.power / 4)} kW
                        </span>
                        <Switch defaultChecked disabled={selectedRoom.status === 'cutoff'} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Quick Actions */}
              <div>
                <h3 className="text-sm font-medium text-slate-400 mb-3">ACTIONS RAPIDES</h3>
                <div className="grid grid-cols-2 gap-2">
                  <button 
                    onClick={() => {
                      updateRoomStatus(selectedRoom.id, 'limited');
                      setSelectedRoomId(null);
                    }}
                    disabled={selectedRoom.status === 'limited'}
                    className="bg-orange-600 hover:bg-orange-700 text-white p-3 rounded text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Limiter Puissance
                  </button>
                  <button 
                    onClick={() => {
                      updateRoomStatus(selectedRoom.id, 'powered');
                      setSelectedRoomId(null);
                    }}
                    disabled={selectedRoom.status === 'powered'}
                    className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded text-sm transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Rétablir
                  </button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}