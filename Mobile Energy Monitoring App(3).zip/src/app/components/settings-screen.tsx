import { useState } from 'react';
import { User, Shield, Bell, Settings, ChevronRight, Lock, Building2 } from 'lucide-react';
import { useBuilding } from '@/app/contexts/building-context';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';

type UserRole = 'super_admin' | 'energy_manager' | 'technician' | 'observer';

export function SettingsScreen() {
  const { activeBuilding } = useBuilding();
  const [currentUser] = useState({
    name: 'Admin Principal',
    role: 'super_admin' as UserRole,
    email: 'admin@university.edu'
  });

  const [showRoleInfo, setShowRoleInfo] = useState(false);
  const [notifications, setNotifications] = useState({
    overload: true,
    cutoff: true,
    limit: true,
    manual: false,
    auto: false
  });

  if (!activeBuilding) {
    return (
      <div className="p-4 flex items-center justify-center h-full">
        <div className="text-center text-slate-400">
          <Building2 className="w-12 h-12 mx-auto mb-2" />
          <p>Aucun bâtiment sélectionné</p>
        </div>
      </div>
    );
  }

  const getRoleName = (role: UserRole) => {
    switch (role) {
      case 'super_admin':
        return 'Super Administrateur';
      case 'energy_manager':
        return 'Gestionnaire Énergie';
      case 'technician':
        return 'Technicien';
      case 'observer':
        return 'Observateur';
    }
  };

  const getRoleColor = (role: UserRole) => {
    switch (role) {
      case 'super_admin':
        return 'bg-red-500';
      case 'energy_manager':
        return 'bg-blue-500';
      case 'technician':
        return 'bg-green-500';
      case 'observer':
        return 'bg-slate-500';
    }
  };

  const roles = [
    {
      role: 'super_admin' as UserRole,
      permissions: [
        'Toutes les actions critiques',
        'Gestion des bâtiments',
        'Modification des règles',
        'Export des données',
        'Accès historique complet'
      ]
    },
    {
      role: 'energy_manager' as UserRole,
      permissions: [
        'Actions de limitation',
        'Création de règles',
        'Export des rapports',
        'Consultation historique'
      ]
    },
    {
      role: 'technician' as UserRole,
      permissions: [
        'Contrôle des équipements',
        'Consultation des salles',
        'Alertes en lecture seule'
      ]
    },
    {
      role: 'observer' as UserRole,
      permissions: [
        'Lecture seule',
        'Consultation dashboard',
        'Aucune action possible'
      ]
    }
  ];

  return (
    <div className="p-4 space-y-4">
      {/* User Profile */}
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <div className="flex items-start gap-4">
          <div className="bg-blue-600 p-3 rounded-full">
            <User className="w-6 h-6 text-white" />
          </div>
          <div className="flex-1">
            <h2 className="font-medium">{currentUser.name}</h2>
            <p className="text-sm text-slate-400">{currentUser.email}</p>
            <Badge className={`${getRoleColor(currentUser.role)} text-white border-0 mt-2`}>
              {getRoleName(currentUser.role)}
            </Badge>
          </div>
        </div>
      </div>

      {/* Security Settings */}
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <h2 className="text-sm font-medium text-slate-400 mb-4">SÉCURITÉ</h2>
        <div className="space-y-3">
          <button 
            onClick={() => setShowRoleInfo(true)}
            className="w-full flex items-center justify-between p-3 bg-slate-700/50 rounded hover:bg-slate-700 transition-colors"
          >
            <div className="flex items-center gap-3">
              <Shield className="w-4 h-4 text-blue-400" />
              <span className="text-sm">Rôles & Permissions</span>
            </div>
            <ChevronRight className="w-4 h-4 text-slate-400" />
          </button>

          <div className="w-full flex items-center justify-between p-3 bg-slate-700/50 rounded">
            <div className="flex items-center gap-3">
              <Lock className="w-4 h-4 text-orange-400" />
              <span className="text-sm">Double confirmation</span>
            </div>
            <Switch defaultChecked />
          </div>

          <div className="p-3 bg-blue-900/30 border border-blue-700 rounded">
            <p className="text-xs text-blue-300 flex items-center gap-2">
              <Shield className="w-3 h-3" />
              Historique non modifiable - Toutes les actions sont tracées
            </p>
          </div>
        </div>
      </div>

      {/* Notifications */}
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <h2 className="text-sm font-medium text-slate-400 mb-4">NOTIFICATIONS</h2>
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded">
            <div className="flex items-center gap-3">
              <Bell className="w-4 h-4 text-red-400" />
              <div>
                <p className="text-sm">Surcharges</p>
                <p className="text-xs text-slate-400">Alertes critiques</p>
              </div>
            </div>
            <Switch
              checked={notifications.overload}
              onCheckedChange={(checked) => setNotifications({ ...notifications, overload: checked })}
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded">
            <div className="flex items-center gap-3">
              <Bell className="w-4 h-4 text-orange-400" />
              <div>
                <p className="text-sm">Coupures</p>
                <p className="text-xs text-slate-400">Coupures électriques</p>
              </div>
            </div>
            <Switch
              checked={notifications.cutoff}
              onCheckedChange={(checked) => setNotifications({ ...notifications, cutoff: checked })}
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded">
            <div className="flex items-center gap-3">
              <Bell className="w-4 h-4 text-yellow-400" />
              <div>
                <p className="text-sm">Limitations</p>
                <p className="text-xs text-slate-400">Limitations de puissance</p>
              </div>
            </div>
            <Switch
              checked={notifications.limit}
              onCheckedChange={(checked) => setNotifications({ ...notifications, limit: checked })}
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded">
            <div className="flex items-center gap-3">
              <Bell className="w-4 h-4 text-blue-400" />
              <div>
                <p className="text-sm">Actions manuelles</p>
                <p className="text-xs text-slate-400">Actions utilisateurs</p>
              </div>
            </div>
            <Switch
              checked={notifications.manual}
              onCheckedChange={(checked) => setNotifications({ ...notifications, manual: checked })}
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-slate-700/50 rounded">
            <div className="flex items-center gap-3">
              <Bell className="w-4 h-4 text-green-400" />
              <div>
                <p className="text-sm">Actions automatiques</p>
                <p className="text-xs text-slate-400">Règles déclenchées</p>
              </div>
            </div>
            <Switch
              checked={notifications.auto}
              onCheckedChange={(checked) => setNotifications({ ...notifications, auto: checked })}
            />
          </div>
        </div>
      </div>

      {/* System Info */}
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <h2 className="text-sm font-medium text-slate-400 mb-4">SYSTÈME</h2>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-slate-400">Version</span>
            <span className="font-mono">1.0.0</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Bâtiment</span>
            <span>{activeBuilding.name}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Dernière synchro</span>
            <span className="font-mono">09/01/2026 14:30</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Mode</span>
            <span className="text-green-400">Production</span>
          </div>
        </div>
      </div>

      {/* About */}
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <div className="flex items-center gap-3 mb-3">
          <Settings className="w-4 h-4 text-blue-400" />
          <h2 className="text-sm font-medium">SMART ENERGY</h2>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          Application de monitoring et contrôle énergétique. Fonctionnement basé sur règles logiques déterministes, sans intelligence artificielle ni API externe.
        </p>
      </div>

      {/* Roles Dialog */}
      <Dialog open={showRoleInfo} onOpenChange={setShowRoleInfo}>
        <DialogContent className="bg-slate-800 text-white border-slate-700 max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Rôles & Permissions</DialogTitle>
            <DialogDescription className="text-slate-400">
              Niveaux d'accès et autorisations
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {roles.map((roleInfo) => (
              <div key={roleInfo.role} className="bg-slate-700/50 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Badge className={`${getRoleColor(roleInfo.role)} text-white border-0`}>
                    {getRoleName(roleInfo.role)}
                  </Badge>
                  {currentUser.role === roleInfo.role && (
                    <Badge variant="outline" className="text-xs border-blue-500 text-blue-400">
                      Votre rôle
                    </Badge>
                  )}
                </div>
                <div className="space-y-1">
                  {roleInfo.permissions.map((permission, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm text-slate-300">
                      <div className="w-1 h-1 rounded-full bg-blue-400"></div>
                      <span>{permission}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}