import { useState } from 'react';
import { Lightbulb, Wind, Plug, Server, Wifi, Power, Building2, AlertTriangle } from 'lucide-react';
import { useBuilding } from '@/app/contexts/building-context';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';

export function Equipment() {
  const { activeBuilding, toggleEquipment, updateRoomStatus, addAlert } = useBuilding();
  const [selectedRoom, setSelectedRoom] = useState<string>('all');
  const [showCutoffDialog, setShowCutoffDialog] = useState(false);
  const [roomToCutoff, setRoomToCutoff] = useState<string | null>(null);

  if (!activeBuilding) {
    return (
      <div className="p-4 flex items-center justify-center h-full">
        <div className="text-center text-slate-400">
          <Building2 className="w-12 h-12 mx-auto mb-2" />
          <p>Aucun bâtiment sélectionné</p>
        </div>
      </div>
    );
  }

  const getIcon = (type: string) => {
    switch (type) {
      case 'éclairage':
        return Lightbulb;
      case 'climatisation':
        return Wind;
      case 'prises':
        return Plug;
      case 'critique':
        return Server;
      default:
        return Plug;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'éclairage':
        return 'text-yellow-400';
      case 'climatisation':
        return 'text-blue-400';
      case 'prises':
        return 'text-purple-400';
      case 'critique':
        return 'text-red-400';
      default:
        return 'text-slate-400';
    }
  };

  const getRoomName = (roomId: string) => {
    const room = activeBuilding.rooms.find(r => r.id === roomId);
    return room?.name || 'Salle inconnue';
  };

  const filteredEquipment = selectedRoom === 'all' 
    ? activeBuilding.equipment 
    : activeBuilding.equipment.filter(eq => eq.roomId === selectedRoom);

  const rooms = ['all', ...activeBuilding.rooms.map(r => r.id)];

  const handleCutoffRoom = (roomId: string) => {
    setRoomToCutoff(roomId);
    setShowCutoffDialog(true);
  };

  const confirmCutoffRoom = () => {
    if (roomToCutoff) {
      updateRoomStatus(roomToCutoff, 'cutoff');
      setShowCutoffDialog(false);
      setRoomToCutoff(null);
    }
  };

  // Group equipment by room
  const equipmentByRoom = activeBuilding.rooms.map(room => ({
    room,
    equipment: activeBuilding.equipment.filter(eq => eq.roomId === room.id)
  }));

  return (
    <div className="p-4 space-y-4">
      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <p className="text-xs text-slate-400 mb-1">Équipements Actifs</p>
          <p className="text-2xl font-bold text-green-400">
            {activeBuilding.equipment.filter(eq => eq.isOn).length}/{activeBuilding.equipment.length}
          </p>
        </div>
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <p className="text-xs text-slate-400 mb-1">Consommation Totale</p>
          <p className="text-2xl font-mono font-bold text-blue-400">
            {activeBuilding.equipment.filter(eq => eq.isOn).reduce((sum, eq) => sum + eq.power, 0)} kW
          </p>
        </div>
      </div>

      {/* Equipment by Room */}
      <div className="space-y-4">
        {equipmentByRoom.map(({ room, equipment }) => (
          <div key={room.id} className="bg-slate-800 rounded-lg border border-slate-700">
            {/* Room Header */}
            <div className="p-4 border-b border-slate-700">
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium">{room.name}</h3>
                <span className="text-xs font-mono text-green-400">{room.power} kW</span>
              </div>
              <div className="flex items-center justify-between">
                <p className="text-xs text-slate-400">
                  {equipment.filter(eq => eq.isOn).length}/{equipment.length} équipements actifs
                </p>
                <button
                  onClick={() => handleCutoffRoom(room.id)}
                  className="flex items-center gap-1 text-xs bg-red-600/20 hover:bg-red-600/30 text-red-400 px-3 py-1 rounded transition-colors"
                  disabled={room.status === 'cutoff'}
                >
                  <Power className="w-3 h-3" />
                  {room.status === 'cutoff' ? 'Salle coupée' : 'Désalimenter'}
                </button>
              </div>
            </div>

            {/* Equipment List */}
            <div className="p-4 space-y-3">
              {equipment.map((item) => {
                const Icon = getIcon(item.type);
                return (
                  <div
                    key={item.id}
                    className="bg-slate-700/50 rounded-lg p-3"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-start gap-2">
                        <div className={`${item.isOn ? 'bg-slate-600' : 'bg-slate-800'} p-1.5 rounded`}>
                          <Icon className={`w-3.5 h-3.5 ${getTypeColor(item.type)}`} />
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">{item.name}</h4>
                          <p className="text-xs text-slate-400 capitalize">{item.type}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`text-xs font-mono ${item.isOn ? 'text-green-400' : 'text-slate-500'}`}>
                          {item.isOn ? item.power : 0} kW
                        </span>
                        <Switch
                          checked={item.isOn}
                          onCheckedChange={() => toggleEquipment(item.id)}
                          disabled={item.type === 'critique' || room.status === 'cutoff'}
                        />
                      </div>
                    </div>
                    {item.type === 'critique' && (
                      <p className="text-xs text-orange-400 flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3" />
                        Équipement critique - Contrôle restreint
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Cutoff Dialog */}
      <Dialog open={showCutoffDialog} onOpenChange={setShowCutoffDialog}>
        <DialogContent className="bg-slate-800 text-white border-slate-700">
          <DialogHeader>
            <DialogTitle>Désalimenter la salle</DialogTitle>
            <DialogDescription className="text-slate-400">
              Êtes-vous sûr de vouloir désalimenter la salle {roomToCutoff ? getRoomName(roomToCutoff) : ''} ? Tous les équipements seront coupés.
            </DialogDescription>
          </DialogHeader>
          <div className="bg-orange-900/30 border border-orange-700 rounded p-3 my-4">
            <p className="text-sm text-orange-300 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              Niveau de risque: MOYEN
            </p>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setShowCutoffDialog(false)}
            >
              Annuler
            </Button>
            <Button
              onClick={confirmCutoffRoom}
              className="bg-red-600 hover:bg-red-700"
            >
              Désalimenter
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}