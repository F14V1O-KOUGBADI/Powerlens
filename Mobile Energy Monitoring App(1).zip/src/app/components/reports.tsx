import { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Download, Calendar, Building2 } from 'lucide-react';
import { useBuilding } from '@/app/contexts/building-context';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

const roomComparisonData = [
  { room: 'Serveur', avant: 105, apres: 95 },
  { room: 'Amphi', avant: 78, apres: 68 },
  { room: 'Salle 1', avant: 48, apres: 42 },
  { room: 'Salle 2', avant: 45, apres: 38 },
  { room: 'Admin', avant: 38, apres: 32 },
];

const circuitData = [
  { name: 'Éclairage', value: 65 },
  { name: 'Climatisation', value: 125 },
  { name: 'Prises', value: 45 },
  { name: 'Équipements', value: 40 },
];

export function Reports() {
  const { activeBuilding } = useBuilding();
  const [period, setPeriod] = useState('week');
  const [reportType, setReportType] = useState('room');

  if (!activeBuilding) {
    return (
      <div className="p-4 flex items-center justify-center h-full">
        <div className="text-center text-slate-400">
          <Building2 className="w-12 h-12 mx-auto mb-2" />
          <p>Aucun bâtiment sélectionné</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      {/* Header */}
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <div className="flex items-center justify-between mb-3">
          <div>
            <h2 className="text-sm font-medium text-slate-400">RAPPORTS & HISTORIQUE</h2>
            <p className="text-xs text-slate-500 mt-1">{activeBuilding.name}</p>
          </div>
          <button className="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded transition-colors">
            <Download className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-xs text-slate-400 block mb-2">Période</label>
            <Select value={period} onValueChange={setPeriod}>
              <SelectTrigger className="bg-slate-700 border-slate-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="day">Aujourd'hui</SelectItem>
                <SelectItem value="week">Cette semaine</SelectItem>
                <SelectItem value="month">Ce mois</SelectItem>
                <SelectItem value="year">Cette année</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-xs text-slate-400 block mb-2">Type de rapport</label>
            <Select value={reportType} onValueChange={setReportType}>
              <SelectTrigger className="bg-slate-700 border-slate-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-slate-700 border-slate-600">
                <SelectItem value="room">Par salle</SelectItem>
                <SelectItem value="circuit">Par circuit</SelectItem>
                <SelectItem value="actions">Historique actions</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="w-4 h-4 text-blue-400" />
            <p className="text-xs text-slate-400">Consommation Totale</p>
          </div>
          <p className="text-2xl font-mono font-bold text-blue-400">33.6 MWh</p>
          <p className="text-xs text-slate-400 mt-1">Cette semaine</p>
        </div>

        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <div className="flex items-center gap-2 mb-2">
            <Calendar className="w-4 h-4 text-green-400" />
            <p className="text-xs text-slate-400">Économies Réalisées</p>
          </div>
          <p className="text-2xl font-mono font-bold text-green-400">4.2 MWh</p>
          <p className="text-xs text-slate-400 mt-1">Grâce aux actions</p>
        </div>
      </div>

      {/* Comparison Chart - Room */}
      {reportType === 'room' && (
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <h2 className="text-sm font-medium text-slate-400 mb-4">COMPARAISON AVANT / APRÈS ACTIONS</h2>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={roomComparisonData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
              <XAxis 
                dataKey="room" 
                stroke="#94a3b8" 
                style={{ fontSize: '12px' }} 
              />
              <YAxis 
                stroke="#94a3b8" 
                style={{ fontSize: '12px' }}
                label={{ value: 'kW', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1e293b',
                  border: '1px solid #475569',
                  borderRadius: '8px',
                  color: '#fff'
                }}
              />
              <Legend 
                wrapperStyle={{ fontSize: '12px' }}
              />
              <Bar dataKey="avant" fill="#f97316" name="Avant" />
              <Bar dataKey="apres" fill="#22c55e" name="Après" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Circuit Chart */}
      {reportType === 'circuit' && (
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <h2 className="text-sm font-medium text-slate-400 mb-4">CONSOMMATION PAR CIRCUIT</h2>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart data={circuitData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#475569" />
              <XAxis 
                dataKey="name" 
                stroke="#94a3b8" 
                style={{ fontSize: '12px' }} 
              />
              <YAxis 
                stroke="#94a3b8" 
                style={{ fontSize: '12px' }}
                label={{ value: 'kW', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#1e293b',
                  border: '1px solid #475569',
                  borderRadius: '8px',
                  color: '#fff'
                }}
              />
              <Bar dataKey="value" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Actions History */}
      {reportType === 'actions' && (
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <h2 className="text-sm font-medium text-slate-400 mb-4">HISTORIQUE DES ACTIONS</h2>
          <div className="space-y-2">
            {[
              { date: '09/01/2026 14:23', action: 'Limitation circuit éclairage - Salle 1', user: 'Règle automatique' },
              { date: '09/01/2026 12:15', action: 'Coupure climatisation - Amphi', user: 'Admin Principal' },
              { date: '08/01/2026 22:00', action: 'Coupure prises non critiques - Toutes salles', user: 'Règle automatique' },
              { date: '08/01/2026 16:45', action: 'Limitation puissance - Salle 2', user: 'Gestionnaire Énergie' },
              { date: '08/01/2026 09:30', action: 'Coupure alimentation - Bureau Admin', user: 'Technicien Support' },
            ].map((entry, idx) => (
              <div key={idx} className="bg-slate-700/50 rounded p-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">{entry.action}</span>
                  <span className="text-xs text-slate-400">{entry.date}</span>
                </div>
                <p className="text-xs text-slate-400">Par: {entry.user}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Detailed Stats Table */}
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <h2 className="text-sm font-medium text-slate-400 mb-4">STATISTIQUES DÉTAILLÉES</h2>
        <div className="space-y-3">
          <div className="flex justify-between items-center pb-2 border-b border-slate-700">
            <span className="text-sm text-slate-400">Total salles actives</span>
            <span className="font-mono">5</span>
          </div>
          <div className="flex justify-between items-center pb-2 border-b border-slate-700">
            <span className="text-sm text-slate-400">Total circuits</span>
            <span className="font-mono">36</span>
          </div>
          <div className="flex justify-between items-center pb-2 border-b border-slate-700">
            <span className="text-sm text-slate-400">Total équipements</span>
            <span className="font-mono">106</span>
          </div>
          <div className="flex justify-between items-center pb-2 border-b border-slate-700">
            <span className="text-sm text-slate-400">Actions automatiques</span>
            <span className="font-mono">15</span>
          </div>
          <div className="flex justify-between items-center pb-2 border-b border-slate-700">
            <span className="text-sm text-slate-400">Actions manuelles</span>
            <span className="font-mono">8</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm text-slate-400">Taux d'utilisation moyen</span>
            <span className="font-mono text-blue-400">78.6%</span>
          </div>
        </div>
      </div>

      {/* Export Options */}
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <h2 className="text-sm font-medium text-slate-400 mb-3">EXPORT</h2>
        <div className="grid grid-cols-2 gap-3">
          <button className="bg-green-600 hover:bg-green-700 text-white p-3 rounded text-sm transition-colors">
            Export Excel
          </button>
          <button className="bg-red-600 hover:bg-red-700 text-white p-3 rounded text-sm transition-colors">
            Export PDF
          </button>
        </div>
      </div>
    </div>
  );
}