import { useState } from 'react';
import { Plus, Trash2, Play, Pause, Building2 } from 'lucide-react';
import { useBuilding } from '@/app/contexts/building-context';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Input } from './ui/input';
import { Label } from './ui/label';

export function ActionsReactions() {
  const { activeBuilding, addActionReaction, updateBuilding } = useBuilding();
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    conditionType: 'threshold' as 'threshold' | 'time' | 'status',
    conditionValue: '',
    actionType: 'cutoff' as 'cutoff' | 'limit' | 'maintain',
    actionTarget: '',
  });

  if (!activeBuilding) {
    return (
      <div className="p-4 flex items-center justify-center h-full">
        <div className="text-center text-slate-400">
          <Building2 className="w-12 h-12 mx-auto mb-2" />
          <p>Aucun bâtiment sélectionné</p>
        </div>
      </div>
    );
  }

  const toggleRule = (ruleId: string) => {
    const updatedRules = activeBuilding.actionReactions.map(rule =>
      rule.id === ruleId ? { ...rule, enabled: !rule.enabled } : rule
    );
    updateBuilding(activeBuilding.id, { actionReactions: updatedRules });
  };

  const deleteRule = (ruleId: string) => {
    const updatedRules = activeBuilding.actionReactions.filter(rule => rule.id !== ruleId);
    updateBuilding(activeBuilding.id, { actionReactions: updatedRules });
  };

  const handleAddRule = () => {
    if (!formData.name.trim()) return;

    addActionReaction({
      name: formData.name,
      enabled: true,
      condition: {
        type: formData.conditionType,
        value: formData.conditionValue,
      },
      action: {
        type: formData.actionType,
        target: formData.actionTarget,
      },
    });

    setShowAddDialog(false);
    setFormData({
      name: '',
      conditionType: 'threshold',
      conditionValue: '',
      actionType: 'cutoff',
      actionTarget: '',
    });
  };

  const getActionColor = (type: string) => {
    switch (type) {
      case 'cutoff':
        return 'bg-red-500';
      case 'limit':
        return 'bg-orange-500';
      case 'maintain':
        return 'bg-green-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getActionText = (type: string) => {
    switch (type) {
      case 'cutoff':
        return 'Couper';
      case 'limit':
        return 'Limiter';
      case 'maintain':
        return 'Maintenir';
      default:
        return 'Action';
    }
  };

  const getConditionText = (type: string) => {
    switch (type) {
      case 'threshold':
        return 'Seuil';
      case 'time':
        return 'Heure';
      case 'status':
        return 'État';
      default:
        return 'Condition';
    }
  };

  return (
    <div className="p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700 flex-1">
          <h2 className="text-sm font-medium text-slate-400 mb-1">ACTIONS & RÉACTIONS</h2>
          <p className="text-2xl font-bold">{activeBuilding.actionReactions.length} Règles</p>
          <p className="text-xs text-slate-400 mt-1">{activeBuilding.name}</p>
        </div>
      </div>

      {/* Add Rule Button */}
      <button
        onClick={() => setShowAddDialog(true)}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-lg flex items-center justify-center gap-2 transition-colors"
      >
        <Plus className="w-5 h-5" />
        <span>Créer une Règle</span>
      </button>

      {/* Rules List */}
      <div className="space-y-3">
        {activeBuilding.actionReactions.length === 0 ? (
          <div className="bg-slate-800 rounded-lg p-8 border border-slate-700 text-center text-slate-400">
            <Play className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Aucune règle configurée</p>
            <p className="text-xs mt-1">Les règles permettent d'automatiser les actions</p>
          </div>
        ) : (
          activeBuilding.actionReactions.map((rule) => (
            <div
              key={rule.id}
              className={`bg-slate-800 rounded-lg p-4 border ${
                rule.enabled ? 'border-blue-500/30' : 'border-slate-700'
              }`}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-medium">{rule.name}</h3>
                    {rule.enabled ? (
                      <span className="bg-green-600 text-xs px-2 py-0.5 rounded flex items-center gap-1">
                        <Play className="w-3 h-3" />
                        Actif
                      </span>
                    ) : (
                      <span className="bg-slate-600 text-xs px-2 py-0.5 rounded flex items-center gap-1">
                        <Pause className="w-3 h-3" />
                        Inactif
                      </span>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => deleteRule(rule.id)}
                  className="text-red-400 hover:text-red-300 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Condition → Action */}
              <div className="bg-slate-700/50 rounded p-3 mb-3">
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-slate-400">SI</span>
                  <span className="bg-blue-600 px-2 py-1 rounded text-xs">
                    {getConditionText(rule.condition.type)}
                  </span>
                  <span className="font-mono text-green-400">{rule.condition.value}</span>
                  <span className="text-slate-400">→</span>
                  <span className={`${getActionColor(rule.action.type)} px-2 py-1 rounded text-xs text-white`}>
                    {getActionText(rule.action.type)}
                  </span>
                  <span className="text-slate-300">{rule.action.target}</span>
                </div>
              </div>

              {/* Toggle */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-700">
                <span className="text-sm text-slate-400">Règle active</span>
                <Switch
                  checked={rule.enabled}
                  onCheckedChange={() => toggleRule(rule.id)}
                />
              </div>
            </div>
          ))
        )}
      </div>

      {/* Add Rule Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="bg-slate-800 text-white border-slate-700">
          <DialogHeader>
            <DialogTitle>Créer une Règle Action → Réaction</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="rule-name">Nom de la règle</Label>
              <Input
                id="rule-name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Ex: Protection surcharge"
                className="bg-slate-700 border-slate-600 text-white mt-1"
              />
            </div>

            <div className="border-t border-slate-700 pt-4">
              <h3 className="text-sm font-medium mb-3">CONDITION (SI)</h3>
              
              <div className="space-y-3">
                <div>
                  <Label htmlFor="condition-type">Type de condition</Label>
                  <Select
                    value={formData.conditionType}
                    onValueChange={(value) => setFormData({ ...formData, conditionType: value as any })}
                  >
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600 text-white">
                      <SelectItem value="threshold">Seuil de puissance</SelectItem>
                      <SelectItem value="time">Heure programmée</SelectItem>
                      <SelectItem value="status">État électrique</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="condition-value">Valeur</Label>
                  <Input
                    id="condition-value"
                    value={formData.conditionValue}
                    onChange={(e) => setFormData({ ...formData, conditionValue: e.target.value })}
                    placeholder={
                      formData.conditionType === 'threshold' ? '330 kW' :
                      formData.conditionType === 'time' ? '22:00' :
                      'Coupé'
                    }
                    className="bg-slate-700 border-slate-600 text-white mt-1"
                  />
                </div>
              </div>
            </div>

            <div className="border-t border-slate-700 pt-4">
              <h3 className="text-sm font-medium mb-3">ACTION (ALORS)</h3>
              
              <div className="space-y-3">
                <div>
                  <Label htmlFor="action-type">Type d'action</Label>
                  <Select
                    value={formData.actionType}
                    onValueChange={(value) => setFormData({ ...formData, actionType: value as any })}
                  >
                    <SelectTrigger className="bg-slate-700 border-slate-600 text-white mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600 text-white">
                      <SelectItem value="cutoff">Couper</SelectItem>
                      <SelectItem value="limit">Limiter</SelectItem>
                      <SelectItem value="maintain">Maintenir</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="action-target">Cible de l'action</Label>
                  <Input
                    id="action-target"
                    value={formData.actionTarget}
                    onChange={(e) => setFormData({ ...formData, actionTarget: e.target.value })}
                    placeholder="Ex: Salles non prioritaires"
                    className="bg-slate-700 border-slate-600 text-white mt-1"
                  />
                </div>
              </div>
            </div>

            <div className="bg-blue-900/30 border border-blue-700 rounded p-3">
              <p className="text-xs text-blue-300">
                ℹ️ Les règles sont exécutées automatiquement et enregistrées dans le journal des alertes.
              </p>
            </div>
          </div>

          <div className="flex gap-2">
            <Button 
              variant="outline" 
              onClick={() => setShowAddDialog(false)}
              className="flex-1"
            >
              Annuler
            </Button>
            <Button 
              onClick={handleAddRule}
              className="flex-1 bg-blue-600 hover:bg-blue-700"
            >
              Créer la règle
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
