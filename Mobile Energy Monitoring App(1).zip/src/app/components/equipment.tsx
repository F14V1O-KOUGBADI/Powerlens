import { useState } from 'react';
import { Lightbulb, Wind, Plug, Server, Wifi, Power, Building2 } from 'lucide-react';
import { useBuilding } from '@/app/contexts/building-context';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

export function Equipment() {
  const { activeBuilding, toggleEquipment } = useBuilding();
  const [selectedRoom, setSelectedRoom] = useState<string>('all');

  if (!activeBuilding) {
    return (
      <div className="p-4 flex items-center justify-center h-full">
        <div className="text-center text-slate-400">
          <Building2 className="w-12 h-12 mx-auto mb-2" />
          <p>Aucun bâtiment sélectionné</p>
        </div>
      </div>
    );
  }

  const getIcon = (type: string) => {
    switch (type) {
      case 'éclairage':
        return Lightbulb;
      case 'climatisation':
        return Wind;
      case 'prises':
        return Plug;
      case 'critique':
        return Server;
      default:
        return Plug;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'éclairage':
        return 'text-yellow-400';
      case 'climatisation':
        return 'text-blue-400';
      case 'prises':
        return 'text-purple-400';
      case 'critique':
        return 'text-red-400';
      default:
        return 'text-slate-400';
    }
  };

  const getRoomName = (roomId: string) => {
    const room = activeBuilding.rooms.find(r => r.id === roomId);
    return room?.name || 'Salle inconnue';
  };

  const filteredEquipment = selectedRoom === 'all' 
    ? activeBuilding.equipment 
    : activeBuilding.equipment.filter(eq => eq.roomId === selectedRoom);

  const rooms = ['all', ...activeBuilding.rooms.map(r => r.id)];

  return (
    <div className="p-4 space-y-4">
      {/* Filter */}
      <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
        <label className="text-xs text-slate-400 block mb-2">FILTRER PAR SALLE</label>
        <Select value={selectedRoom} onValueChange={setSelectedRoom}>
          <SelectTrigger className="bg-slate-700 border-slate-600">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-slate-700 border-slate-600">
            <SelectItem value="all">Toutes les salles</SelectItem>
            {activeBuilding.rooms.map(room => (
              <SelectItem key={room.id} value={room.id}>{room.name}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <p className="text-xs text-slate-400 mb-1">Équipements Actifs</p>
          <p className="text-2xl font-bold text-green-400">
            {activeBuilding.equipment.filter(eq => eq.isOn).length}/{activeBuilding.equipment.length}
          </p>
        </div>
        <div className="bg-slate-800 rounded-lg p-4 border border-slate-700">
          <p className="text-xs text-slate-400 mb-1">Puissance Totale</p>
          <p className="text-2xl font-mono font-bold text-blue-400">
            {activeBuilding.equipment.filter(eq => eq.isOn).reduce((sum, eq) => sum + eq.power, 0)} kW
          </p>
        </div>
      </div>

      {/* Equipment List */}
      <div className="space-y-3">
        {filteredEquipment.length === 0 ? (
          <div className="bg-slate-800 rounded-lg p-8 border border-slate-700 text-center text-slate-400">
            <Server className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>Aucun équipement trouvé</p>
          </div>
        ) : (
          filteredEquipment.map((item) => {
            const Icon = getIcon(item.type);
            return (
              <div
                key={item.id}
                className="bg-slate-800 rounded-lg p-4 border border-slate-700"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3">
                    <div className={`${item.isOn ? 'bg-slate-700' : 'bg-slate-800'} p-2 rounded`}>
                      <Icon className={`w-4 h-4 ${getTypeColor(item.type)}`} />
                    </div>
                    <div>
                      <h3 className="font-medium text-sm">{item.name}</h3>
                      <p className="text-xs text-slate-400">{getRoomName(item.roomId)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Wifi className="w-3 h-3 text-blue-400" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div>
                    <p className="text-xs text-slate-400">Puissance</p>
                    <p className={`font-mono text-sm ${item.isOn ? 'text-green-400' : 'text-slate-500'}`}>
                      {item.isOn ? item.power : 0} kW
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-400">Statut</p>
                    <p className={`text-sm font-medium ${item.isOn ? 'text-green-400' : 'text-red-400'}`}>
                      {item.isOn ? 'Actif' : 'Inactif'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-slate-700">
                  <span className="text-sm">Contrôle</span>
                  <Switch
                    checked={item.isOn}
                    onCheckedChange={() => toggleEquipment(item.id)}
                    disabled={item.type === 'critique'}
                  />
                </div>
                {item.type === 'critique' && (
                  <p className="text-xs text-orange-400 mt-2">⚠️ Équipement critique - Contrôle restreint</p>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}