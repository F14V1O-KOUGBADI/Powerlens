import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type BuildingType = 'campus' | 'école' | 'bureau' | 'usine';
export type BuildingStatus = 'powered' | 'limited' | 'cutoff';

export interface Room {
  id: string;
  name: string;
  status: BuildingStatus;
  power: number;
  isPriority: boolean;
}

export interface Equipment {
  id: string;
  roomId: string;
  name: string;
  type: 'éclairage' | 'climatisation' | 'prises' | 'critique';
  power: number;
  isOn: boolean;
}

export interface ActionReaction {
  id: string;
  name: string;
  enabled: boolean;
  condition: {
    type: 'threshold' | 'time' | 'status';
    value: string | number;
    room?: string;
  };
  action: {
    type: 'cutoff' | 'limit' | 'maintain';
    target: string;
  };
}

export interface Alert {
  id: string;
  timestamp: string;
  type: 'surcharge' | 'coupure' | 'limitation' | 'action';
  room?: string;
  message: string;
  origin: 'manuel' | 'règle';
}

export interface Building {
  id: string;
  name: string;
  type: BuildingType;
  status: BuildingStatus;
  maxPower: number;
  currentPower: number;
  rooms: Room[];
  equipment: Equipment[];
  actionReactions: ActionReaction[];
  alerts: Alert[];
}

interface BuildingContextType {
  buildings: Building[];
  activeBuilding: Building | null;
  addBuilding: (building: Omit<Building, 'id'>) => void;
  updateBuilding: (id: string, building: Partial<Building>) => void;
  deleteBuilding: (id: string) => void;
  setActiveBuilding: (id: string) => void;
  updateRoomStatus: (roomId: string, status: BuildingStatus) => void;
  toggleEquipment: (equipmentId: string) => void;
  addActionReaction: (rule: Omit<ActionReaction, 'id'>) => void;
  addAlert: (alert: Omit<Alert, 'id' | 'timestamp'>) => void;
}

const BuildingContext = createContext<BuildingContextType | undefined>(undefined);

const DEFAULT_BUILDINGS: Building[] = [
  {
    id: '1',
    name: 'Bâtiment Principal',
    type: 'campus',
    status: 'powered',
    maxPower: 350,
    currentPower: 275,
    rooms: [
      { id: 'r1', name: 'Salle 1', status: 'powered', power: 45, isPriority: false },
      { id: 'r2', name: 'Salle 2', status: 'powered', power: 38, isPriority: false },
      { id: 'r3', name: 'Salle Serveur', status: 'powered', power: 120, isPriority: true },
      { id: 'r4', name: 'Amphi', status: 'powered', power: 52, isPriority: false },
      { id: 'r5', name: 'Bureau Administration', status: 'powered', power: 20, isPriority: false },
    ],
    equipment: [
      { id: 'e1', roomId: 'r1', name: 'Éclairage LED', type: 'éclairage', power: 8, isOn: true },
      { id: 'e2', roomId: 'r1', name: 'Climatisation', type: 'climatisation', power: 25, isOn: true },
      { id: 'e3', roomId: 'r1', name: 'Prises murales', type: 'prises', power: 12, isOn: true },
      { id: 'e4', roomId: 'r3', name: 'Serveurs', type: 'critique', power: 80, isOn: true },
      { id: 'e5', roomId: 'r3', name: 'Climatisation serveur', type: 'critique', power: 35, isOn: true },
    ],
    actionReactions: [
      {
        id: 'ar1',
        name: 'Protection surcharge',
        enabled: true,
        condition: { type: 'threshold', value: 330, room: 'all' },
        action: { type: 'cutoff', target: 'salles non prioritaires' }
      },
      {
        id: 'ar2',
        name: 'Extinction nocturne',
        enabled: true,
        condition: { type: 'time', value: '22:00', room: 'all' },
        action: { type: 'cutoff', target: 'prises salles de cours' }
      }
    ],
    alerts: [
      {
        id: 'a1',
        timestamp: new Date().toISOString(),
        type: 'action',
        room: 'Salle 1',
        message: 'Règle "Protection surcharge" exécutée',
        origin: 'règle'
      }
    ]
  }
];

export function BuildingProvider({ children }: { children: ReactNode }) {
  const [buildings, setBuildings] = useState<Building[]>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('smartenergy_buildings');
      return stored ? JSON.parse(stored) : DEFAULT_BUILDINGS;
    }
    return DEFAULT_BUILDINGS;
  });
  
  const [activeBuildingId, setActiveBuildingId] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('smartenergy_active_building');
      return stored || (buildings.length > 0 ? buildings[0].id : '');
    }
    return buildings.length > 0 ? buildings[0].id : '';
  });

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('smartenergy_buildings', JSON.stringify(buildings));
    }
  }, [buildings]);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('smartenergy_active_building', activeBuildingId);
    }
  }, [activeBuildingId]);

  const activeBuilding = buildings.find(b => b.id === activeBuildingId) || null;

  const addBuilding = (building: Omit<Building, 'id'>) => {
    const newBuilding: Building = {
      ...building,
      id: Date.now().toString(),
    };
    setBuildings(prev => [...prev, newBuilding]);
    setActiveBuildingId(newBuilding.id);
  };

  const updateBuilding = (id: string, updates: Partial<Building>) => {
    setBuildings(prev => 
      prev.map(b => b.id === id ? { ...b, ...updates } : b)
    );
  };

  const deleteBuilding = (id: string) => {
    setBuildings(prev => {
      const filtered = prev.filter(b => b.id !== id);
      if (activeBuildingId === id && filtered.length > 0) {
        setActiveBuildingId(filtered[0].id);
      }
      return filtered;
    });
  };

  const setActiveBuilding = (id: string) => {
    if (buildings.find(b => b.id === id)) {
      setActiveBuildingId(id);
    }
  };

  const updateRoomStatus = (roomId: string, status: BuildingStatus) => {
    if (!activeBuilding) return;
    
    updateBuilding(activeBuilding.id, {
      rooms: activeBuilding.rooms.map(r => 
        r.id === roomId ? { ...r, status } : r
      )
    });

    addAlert({
      type: status === 'cutoff' ? 'coupure' : status === 'limited' ? 'limitation' : 'action',
      room: activeBuilding.rooms.find(r => r.id === roomId)?.name,
      message: `État changé: ${status}`,
      origin: 'manuel'
    });
  };

  const toggleEquipment = (equipmentId: string) => {
    if (!activeBuilding) return;
    
    updateBuilding(activeBuilding.id, {
      equipment: activeBuilding.equipment.map(e => 
        e.id === equipmentId ? { ...e, isOn: !e.isOn } : e
      )
    });
  };

  const addActionReaction = (rule: Omit<ActionReaction, 'id'>) => {
    if (!activeBuilding) return;
    
    const newRule: ActionReaction = {
      ...rule,
      id: Date.now().toString(),
    };
    
    updateBuilding(activeBuilding.id, {
      actionReactions: [...activeBuilding.actionReactions, newRule]
    });
  };

  const addAlert = (alert: Omit<Alert, 'id' | 'timestamp'>) => {
    if (!activeBuilding) return;
    
    const newAlert: Alert = {
      ...alert,
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
    };
    
    updateBuilding(activeBuilding.id, {
      alerts: [newAlert, ...activeBuilding.alerts]
    });
  };

  return (
    <BuildingContext.Provider
      value={{
        buildings,
        activeBuilding,
        addBuilding,
        updateBuilding,
        deleteBuilding,
        setActiveBuilding,
        updateRoomStatus,
        toggleEquipment,
        addActionReaction,
        addAlert,
      }}
    >
      {children}
    </BuildingContext.Provider>
  );
}

export function useBuilding() {
  const context = useContext(BuildingContext);
  if (context === undefined) {
    throw new Error('useBuilding must be used within a BuildingProvider');
  }
  return context;
}